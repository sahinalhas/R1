from app.utils.program import generate_weekly_schedule, calculate_topic_schedule
from app.utils.filters import register_filters